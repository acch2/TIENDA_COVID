import React, { Component } from 'react';
class NoEncontrado extends Component {
	render(){
		return(
			<div id="noencontrado">
				<h1 align="center">Página no encontrada</h1>
			</div>
		);
	}
}
export default NoEncontrado;