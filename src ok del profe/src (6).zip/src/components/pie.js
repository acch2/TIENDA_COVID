import React, { Component } from 'react';
class Pie extends Component {
	render(){
		return(
			<p>CodigoStore - Todos los derechos reservados &copy; 2020</p>
		);
	}
}
export default Pie;