import React, { Component } from 'react';
import { Route, Switch } from 'react-router-dom';
import { AppProvider } from './helpers/appcontext';
import Cabecera from './components/cabecera';
import Pie from './components/pie';
import Principal from './components/principal';
import ProductoDetalle from './components/producto_detalle';
import Login from './components/login';
import Carrito from './components/carrito';
import Buscar from './components/buscar';
import NoEncontrado from './components/noencontrado';
import './App.css';

class App extends Component {
  setCarrito = (carrito)=>{
    this.setState({ carrito });
  };
  state = {
    carrito: [
      {id:88,nombre:"demo",precio:3,cantidad:9}
    ],
    setCarrito: this.setCarrito
  };
  componentDidMount(){
    console.log("componentDidMount App");
    if(localStorage.carrito){
      console.log("localStorage.carrito");
      this.setState({
        carrito: JSON.parse(localStorage.carrito)
      });
    }
  }
  render(){
    return(
      <AppProvider value={this.state}>
        <header>
          <Cabecera></Cabecera>
        </header>
        <main>
          <Switch>
            <Route exact path='/' component={ Principal } />
            <Route exact path='/producto/detalle/:id' component={ ProductoDetalle } />
            <Route exact path='/login' component={ Login } />
            <Route exact path='/carrito' component={ Carrito } />
            <Route exact path='/buscar/:busqueda' component={ Buscar } />
            <Route component={ NoEncontrado } />
          </Switch>
        </main>
        <footer>
          <Pie></Pie>
        </footer>
      </AppProvider>
    );
  }
}

export default App;
