import React, { Component } from 'react';
import Cabecera from './cabecera';
class ProductoDetalle extends Component {
	idprod = this.props.match.params.id;
	agregar(){
		window.alert("agregar");
		Cabecera.setState({
			cantidad: 1
		});
	}
	render(){
		return(
			<div id="producto_detalle">
				<div className="ruta">Inicio / Producto / Nombre del Producto</div>
				<div className="caja_producto">
					<div className="imagen"><img src="/img/fanta.jpg" alt="" /></div>
					<div className="datos">
						<h2>Nombre del Producto</h2>
						<div className="precio">S/ 3.60</div>
						<div className="controles">
							<input type="number" className="cajaCantidad" />
							<button className="btnCarrito" onClick={this.agregar.bind(this)}>Agregar al carrito</button>
						</div>
					</div>
				</div>
			</div>
		);
	}
}
export default ProductoDetalle;